<?php

include_once __DIR__ . "/init.php";
include_once "{$_(PATH_APPLICATION)}/core/Router.php";
include_once "{$_(PATH_APPLICATION)}/core/Controller.php";
include_once "{$_(PATH_APPLICATION)}/core/Database.php";
