<!DOCTYPE html>
<html lang="vi">

<head>
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/common/Head_Component.php" ?>
</head>

<body>
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/common/Totop_Component.php" ?>
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/common/Form_Login_Component.php" ?>
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/common/Header_Component.php" ?>
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/home/Home_Main_Component.php" ?>
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/common/Footer_Component.php" ?>
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/common/JS_Import_Component.php" ?>
</body>