<div class="row bg-light py-3 rounded my-3">
     <div class="col-12">
          <h3 class="text-primary text-center text-lg-left"><i class="fa fa-stream" aria-hidden="true"></i>
               Danh mục sản phẩm</h3>
          <hr>
     </div>

     <?php include_once "{$_(PATH_APPLICATION)}/views/components/home/Category_Item_Component.php" ?>
</div>