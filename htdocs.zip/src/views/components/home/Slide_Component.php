<div class="owl-carousel owl-theme">
     <a href="#"><img src="/public/img/slide/1.jpg" class="img-fluid"></a>
     <a href="#"><img src="/public/img/slide/2.jpg"></a>
     <a href="#"><img src="/public/img/slide/3.jpg"></a>
     <a href="#"><img src="/public/img/slide/4.jpg"></a>
     <a href="#"><img src="/public/img/slide/5.jpg"></a>
     <a href="#"><img src="/public/img/slide/6.jpg"></a>
</div>