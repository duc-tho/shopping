<?php include_once "{$_(PATH_APPLICATION)}/views/components/home/Slide_Component.php" ?>

<main class="container">
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/home/Category_Component.php" ?>
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/product/Product_Component.php" ?>
</main>