<script src="/public/js/home.js"></script>
<!-- <script src="/js/cart.js"></script> -->