<footer class="container-fluid ms-bg-dark py-3">
     <div class="row text-center text-md-left">
          <div class="col-md-3 mx-auto">
               <h5 class="text-light lead">Liên Hệ</h5>
               <span class="text-secondary">Email: abc@xyzs</span><br>
               <span class="text-secondary">Địa chỉ: Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt,
                    omnis! Eaque praesentium provident tempore, esse eveniet tenetur, nihil libero itaque dolor corporis
                    sunt cupiditate. Debitis minima tempore consectetur inventore similique.</span>
          </div>
          <div class="col-md-3 mx-auto">
               <h5 class="text-light lead">Kết Nối với chúng tôi</h5>
               <a href="https://www.facebook.com/3ei3isaki" target="_blank"><span class="text-secondary">Facebook</span></a><br>
               <a href="#"><span class="text-secondary">Youtube</span></a><br>
               <a href="#"><span class="text-secondary">Instagram</span></a><br>
               <a href="#"><span class="text-secondary">Twitter</span></a>
          </div>
          <div class="col-md-3 mx-auto">
               <h5 class="text-light lead">Trợ Giúp</h5>
               <a href="#"><span class="text-secondary">Thứ 2 đến CN: 9h - 18h (Hotline), 7h - 22h (chat trực
                         tuyến)</span></a><br>
               <a href="#"><span class="text-secondary">Trung tâm hỗ trợ</span></a><br>
               <a href="#"><span class="text-secondary">Hướng dẫn đặt hàng</span></a><br>
               <a href="#"><span class="text-secondary">Giao hàng & Nhận hàng</span></a><br>
               <a href="#"><span class="text-secondary">Hướng dẫn đổi trả hàng</span></a>

          </div>
     </div>
     <hr class="bg-secondary">
     <div class="col-12">
          <span class="text-center d-block text-light lead">Thiết Kế bởi Ngô Đức Thọ - 18607095</span>
     </div>
</footer>