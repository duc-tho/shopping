<main class="container">
     <?php include_once "{$_(PATH_APPLICATION)}/views/components/product/Product_Component.php" ?>
</main>