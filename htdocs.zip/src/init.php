<?php
$GLOBALS["_"] = function ($param) {
     return $param;
};

// Database Param
define("DB_HOST", "localhost");
define("DB_USER", "rpqtqxaw_mei");
define("DB_PASS", "ngoductho18607095");
define("DB_DATABASE", "rpqtqxaw_meishop");

// Defaut Param
define("DEFAULT_CONTROLLER", "Error");
define("DEFAULT_ACTION", "index");

// PATH
define("PATH_APPLICATION", __DIR__);
