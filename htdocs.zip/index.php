<?php

session_start();
include_once "./src/application.php";
$App = new Router();
